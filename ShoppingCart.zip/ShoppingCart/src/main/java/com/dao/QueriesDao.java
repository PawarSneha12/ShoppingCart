package com.dao;

import com.model.Queries;

public interface QueriesDao {

 	void addQuery(Queries queries);
}
